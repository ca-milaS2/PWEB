let idade;
let opniao;
let sexo;
let idadeMedia = 0;
let idadeVelha = 0;
let idadeNova = 0;
let qtdeMulher = 0;
let qtdeHomem = 0;
let qtdeOutro = 0;
let porcen1 = 0.0;
let porcen2 = 0.0;

alert("Seja-bem vindo a pesquisa, são três perguntas!");

for(let cont = 0; cont < 45; cont++) {
    idade = prompt("Qual é a sua idade?");
    idade = parseInt(idade);

    opniao = prompt("Qual foi a sua opnião do filme? (1 - Péssimo, 2 - Regular, 3 - Bom, 4 - Ótimo)");
    opniao = parseInt(opniao);

    sexo = prompt("Qual o seu sexo? (F - Feminino, M - Masculino, O - Outro)");

    idadeMedia = idadeMedia + idade;

    if(idadeVelha == 0 && idadeNova == 0) {
        idadeVelha = idade;
        idadeNova = idade;
    }

    if(idadeVelha < idade) {
        idadeVelha = idade;
    }   

    if(idadeNova > idade) {
        idadeNova = idade;
    }

    switch (sexo) {
        case 'F':
            qtdeMulher = qtdeMulher + 1;
            break;
        case 'M':
            qtdeHomem = qtdeHomem + 1;
            break;
        case 'O':
            qtdeOutro = qtdeOutro + 1;
            break;
    }

    if(opniao == 1) {
        porcen1 = porcen1 + 1;
    }
    else {
        if(opniao == 3 || opniao == 4) {
            porcen2 = porcen2 + 1
        }
    }
}

idadeMedia = Math.round(idadeMedia/45);
porcen1 = Math.round((porcen1 * 100)/45);
porcen2 = Math.round((porcen2 * 100)/45);

alert("Idade" + "\n\nMédia da Idade: " + idadeMedia + "\nIdade mais velha: " + idadeVelha 
    + "\nIdade mais nova: " + idadeNova);

alert("Opnião" + "\n\nPorcentagem de Péssimos: " + porcen1 + "%" + "\nPorcentagem de Bom e Ótimo: " + porcen2 + "%");

alert("Sexo" + "\n\nQuantidade de Mulheres: " 
    + qtdeMulher + "\nQuantidade de Homens: " + qtdeHomem + "\nQuantidade de Outros: " + qtdeOutro);