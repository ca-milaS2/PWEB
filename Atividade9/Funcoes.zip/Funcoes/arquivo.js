function maiorValor() {
    let num1 = parseFloat(document.getElementById("num1").value);
    let num2 = parseFloat(document.getElementById("num2").value);
    let num3 = parseFloat(document.getElementById("num3").value);

    if(isNaN(num1) || isNaN(num2) || isNaN(num3)) 
        alert("Erro, todos os campos precisam ser respondidos com algum valor numérico");
    else {
        let result = Math.max(num1, num2, num3);
        return alert("O maior número é: " + result);
    }
}

function ordemCrescente() {
    let val = [parseFloat(document.getElementById("num1").value), 
               parseFloat(document.getElementById("num2").value), 
               parseFloat(document.getElementById("num3").value)];

        if(isNaN(val[0]) || isNaN(val[1]) || isNaN(val[2]))
            alert("Erro, todos os campos precisam ser respondidos com algum valor numérico");
        else {              
            let result = val.sort((a, b) => a - b); 
            return alert("Ordem Crescente: " + val[0] + " " + val[1] + " " + val[2]);
        }
}

function palindromo() {
    let palv = (document.getElementById("palavra").value).toUpperCase();
    palv = palv.replace(/[^\w\s]|_/g, '').replace(/\s+/g, ' ');
    let aux = 0;

    if(palv === "" && !isNaN(palv)) {
        alert("Erro, todos os campos precisam ser preenchidos com caractéres alfabéticos");
    }
    else {
    for(cont = 0; cont < palv.length; cont++) {
        if(palv[cont] == palv[palv.length - cont - 1])
            aux = aux + 1;
        else
            break;
    }

    if(aux > 0)
        return alert("Essa palavra é um palíndromo!");
    else
        return alert("Essa palavra não é um palíndromo!");
    }
}

function subconjunto() {
    let palv1 = (document.getElementById("palavra1").value).toUpperCase();
    let palv2 = (document.getElementById("palavra2").value).toUpperCase();

    if(!isNaN(palv1) || !isNaN(palv2) || palv1 === "" || palv2 === "") {
        alert("Erro, todos os campos precisam ser preenchidos com caractéres alfabéticos");
    }
    else
        if(palv1.includes(palv2) || palv2.includes(palv1))
            return alert("É um subconjunto");
        else
            return alert("Não é um subconjunto!");
}

function diaDaSemena() {
    let data1 = document.getElementById("data").value;

    if(data1 === "")
        return alert("Erro, todos os campos precisam ser respondidos com algum valor numérico");
    else {
        let semana = new Date(data1).getDay();
        switch (semana) {
            case 0:
                return alert("Segunda-feira");
                break;
            case 1:
                return alert("Terça-feira");
                break;
            case 2:
                return alert("Quarta-feira");
                break;
            case 3:
                return alert("Quinta-feira");
                break;
            case 4:
                return alert("Sexta-feira");
                break;
            case 5:
                return alert("Sábado");
                break;
            case 6:
                return alert("Domingo");
                break;
        }
    }
}

function apagar() {
    document.getElementById("num1").value = " ";
    document.getElementById("num2").value = " ";
    document.getElementById("num3").value = " ";
}

function apagarPalindromo() {
    document.getElementById("palavra").value = " ";
}

function apagarSubconjunto() {
    document.getElementById("palavra1").value = " ";
    document.getElementById("palavra2").value = " ";
}

function apagarData() {
    document.getElementById("data").value = " ";
}