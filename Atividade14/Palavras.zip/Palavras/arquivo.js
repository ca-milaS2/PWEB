function mudarTamanho() {
    let opcao = document.querySelector('input[name="opcao"]:checked');
    let palavra = document.getElementById("palvr").value;
    let novoTamanho;

    if(opcao.value === "maiuscula") {
        novoTamanho = palavra.toUpperCase();
    } 
    else {
        novoTamanho = palavra.toLowerCase();
    }

    return alert(`${novoTamanho}`);
}