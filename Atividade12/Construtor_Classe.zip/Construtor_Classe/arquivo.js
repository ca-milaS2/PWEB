function calcAreaRetangulo() {

    function Retangulo(b, a) {
        this.b = b;
        this.a = a;
        this.calcArea = function() {
            let result = this.b * this.a;
            return result;
        }
    }

    let base = parseFloat(document.getElementById("base").value);
    let altura = parseFloat(document.getElementById("alt").value);

    if(isNaN(base) || isNaN(altura)) {
        alert("Erro, todos os campos precisam ser respondidos com algum valor numérico");
    }
    else if(base <= 0 || altura <=0)
    {
        alert("Erro, todos os campos númericos precisam ser maiores que 0");
    }
        else {
            var retangulo = new Retangulo(base, altura);
            alert(`O valor da área é: ${retangulo.calcArea()}`);
        }
}

function mostrarContas() {
    class Conta {
        constructor() {
            this._nome;
            this._nomeBanco;
            this._numConta;
            this._saldo;
        }

        setNome(value) {
            this._nome = value;
        }

        getNome() {
            return this._nome;
        }

        setNomeBanco(value) {
            this._nomeBanco = value;
        }

        getNomeBanco() {
            return this._nomeBanco;
        }

        setNumConta(value) {
            this._numConta = value;
        }

        getNumConta() {
            return this._numConta;
        }

        getSaldo() {
            return this._saldo;
        }

        setSaldo(value) {
            this._saldo = value;
        }
    }

        class ContaCorrente extends Conta {
            constructor() {
                super();
                this._saldoEsp;
            }

            setSaldoEsp(value) {
                this._saldoEsp = value;
            }

            getSaldoEsp() {
                return this._saldoEsp;
            }
        }

        class ContaPoupanca extends Conta {
            constructor() {
                super();
                this._juros;
                this.dataVensc;
            }

            setJuros(value) {
                this._juros = value;
            }

            getJuros() {
               return this._juros;
            }

            setDataVensc(value) {
                this._dataVensc = value;
            }

            getDataVensc() {
                return this._dataVensc;
            }
        }

        let objContaC = new ContaCorrente();
        objContaC.setNome(document.getElementById("nome").value);
        objContaC.setNomeBanco(document.getElementById("banco").value);
        objContaC.setNumConta(parseInt(document.getElementById("num").value));
        objContaC.setSaldo(parseFloat(document.getElementById("saldo").value));
        objContaC.setSaldoEsp(parseFloat(document.getElementById("saldoE").value));

        let objContaP = new ContaPoupanca();
        objContaP.setNome(document.getElementById("nome").value);
        objContaP.setNomeBanco(document.getElementById("banco").value);
        objContaP.setNumConta(parseInt(document.getElementById("num").value));
        objContaP.setSaldo(parseFloat(document.getElementById("saldo").value));
        objContaP.setJuros(parseFloat(document.getElementById("juros").value));
        objContaP.setDataVensc(document.getElementById("dataV").value);

        alert(`Nome: ${objContaC.getNome()} \nBanco: ${objContaC.getNomeBanco()} \nConta: ${objContaC.getNumConta()} \nSaldo: R$${objContaC.getSaldo()} \nSaldo Especial: R$${objContaC.getSaldoEsp()}`);
        alert(`Nome: ${objContaP.getNome()} \nBanco: ${objContaP.getNomeBanco()} \nConta: ${objContaP.getNumConta()} \nSaldo: R$${objContaP.getSaldo()} \nJuros: ${objContaP.getJuros()}% \nData Venscimento: ${objContaP.getDataVensc()}`);
    }

function limpar() {
    document.getElementById("base").value = " ";
    document.getElementById("alt").value = " ";
}