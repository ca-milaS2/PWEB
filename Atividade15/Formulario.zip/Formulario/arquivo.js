function limpar() {
    document.getElementById("nome").value = " ";
    document.getElementById("email").value = " ";
    document.getElementById("coment").value = " ";
    document.getElementById("sim").checked = false;
    document.getElementsByName("nao").checked = false;
}

function enviar() {
    let nome = document.getElementById("nome").value;
    let email = document.forms[0].elements[1].value;
    let comentario = document.forms[0].elements[2].value;
    let opcao = document.querySelector('input[name="opcao"]:checked');

    if(nome.length <= 10) {
        document.getElementById("nome").focus();
        return alert("O nome precisa ter mais de 10 caractéres");
    }

    if(comentario.length < 20) {
        document.getElementById("coment").focus();
        return alert("O comentário precisa ter pelo menos de 20 caractéres");
    }

    if(opcao.value === "sim") {
        return alert("Que bom que você voltou a visitar esta página!");
    }
    else 
            return alert("Volte sempre à esta página!");
}