alert("Seja bem-vindo ao jogo Pedra, Papel e Tesoura!");
alert("As opções são: " + "\n1 - Pedra" + "\n2 - Papel" + "\n3 - Tesoura");

let opcao = prompt("Escolha a opção: ");
opcao = parseFloat(opcao);

if(opcao > 3 || opcao < 1 || isNaN(opcao)) {
    alert("Opção inválida :(");
}
else {
    let numAleatorio = (Math.round(Math.random() * 10));
    while (numAleatorio == 0 || numAleatorio > 3) {
        numAleatorio = (Math.random() * 10);
        numAleatorio = Math.round(numAleatorio);
    }

    numAleatorio = Math.round(numAleatorio);
    alert("Valor do usuário: " + opcao + "\nValor do computador: " + numAleatorio);

    if(numAleatorio == opcao) {
        alert("Que sorte, foi empate!");
    }
    else {
        if((numAleatorio == 1 && opcao == 2) || (numAleatorio == 2 && opcao == 1)){
            alert("Pedra quebra tesoura");
        }
        else {
            if((numAleatorio == 2 && opcao == 3) || (numAleatorio == 3 && opcao == 2)) {
                alert("Tesoura corta papel");
            }
            else {
                alert("Papel cobre a pedra");
            }
        }
    }
}