function Aberta() {
    document.getElementById("imagem").src = 'assent/JanelaAberta.jpg';
    document.getElementById("texto").innerHTML = " A janela está aberta, o gatinho gostou!"
}

function Fechada() {
    document.getElementById("imagem").src = 'assent/JanelaFechada.jpg';
    document.getElementById("texto").innerHTML = "A janela está fechada, abra para o gatinho!"
}

function Quebrada() {
    event.preventDefault();
    document.getElementById("imagem").src = 'assent/JanelaQuebrada.jpg';
    document.getElementById("texto").innerHTML = "A janela está quebrada??! Cadê o gatinho!"
}